# CT-BN-Compat v2.0.24

Purpose: diagnostic-only correction for malformed NeoForge annotation metadata that caused automatic subscriber/mod annotation scanning to fail before runtime diagnostics registered.

## Change

- Packaged `@Mod(dist=...)` metadata now uses a `Dist[]` array value instead of a scalar enum value.
- The source annotation uses explicit array syntax: `dist = {Dist.CLIENT}` so future compiles fail fast if a wrong local/stub annotation is used.
- The final JAR was audited for `net.neoforged.fml.common.EventBusSubscriber`; none are present.
- Explicit `NeoForge.EVENT_BUS.addListener(ClientRuntimeDiagnostics::onClientTick)` remains the runtime diagnostic registration path.

## Preserved

- Working `ScreenRenderMixin` CLASS-retention Mixin annotation metadata.
- Bootstrap-safe mixin plugin.
- JEI ingredient-grid, `JeiTooltip`, and `JeiRenderHelper` diagnostics.
- Existing Minecraft/NeoForge descriptor fixes.
- Diagnostic-only behavior; no tooltip behavior fix was introduced.

## Artifact

- JAR: `CT-BN-Compat-1.21.1-v2.0.24.jar`
- Source snapshot: `CT-BN-Compat-1.21.1-v2.0.24-source.zip`

- SHA-256: `35380b5bababf83cebd15b620d6962104f16be83ada72b946024b098fce12638`
