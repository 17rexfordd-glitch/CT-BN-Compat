# CT-BN-Compat v2.0.24

Purpose: diagnostic-only correction for Sponge Mixin annotation retention in the final packaged JAR.

Key verification target:
- All configured Mixin classes store `org.spongepowered.asm.mixin.Mixin` under `RuntimeInvisibleAnnotations`.
- `@Mixin` is not present under class-level `RuntimeVisibleAnnotations`.
- No `org/spongepowered/...` stub classes are bundled.
- JEI hover/tooltip diagnostics from v2.0.20+ are preserved.

Built artifact produced in chat: `CT-BN-Compat-1.21.1-v2.0.24.jar`
SHA-256: `1fcff03c89b9c6dc54b812b0869f2521daf5f8e6c90edd35337f0eee80e94c5a`
