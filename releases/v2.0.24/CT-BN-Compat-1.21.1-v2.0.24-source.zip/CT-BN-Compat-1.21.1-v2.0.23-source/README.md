# CT-BN-Compat 1.21.1 v2.0.17 — recovered source project

This project was recovered from the exact compiled `CT-BN-Compat-1.21.1-v2.0.17.jar` produced in the ChatGPT build workflow.

It is not claimed to be an untouched historical source checkout: the original project was not stored in Git/GitHub. The Java sources here were reconstructed from the final v2.0.17 class bytecode plus the build artifacts retained in the conversation workspace. The intent is to preserve the compiled v2.0.17 behavior and provide a proper source base for v2.0.19+.

Target:
- Minecraft 1.21.1
- NeoForge 21.1.248
- Java 21
- ColorTooltips 1211.3.4

Build with a Java 21 Gradle environment using `gradle build` (or generate/use a Gradle wrapper first). The build file uses the exact ColorTooltips Curse Maven release used by the diagnostics.

The current branch is diagnostic-only: `clean-baseline=true`, `behavioral-fixes=false`.
