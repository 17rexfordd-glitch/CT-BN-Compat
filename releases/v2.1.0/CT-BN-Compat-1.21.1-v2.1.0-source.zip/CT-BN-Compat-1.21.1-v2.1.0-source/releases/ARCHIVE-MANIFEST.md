# CT-BN-Compat Release Archive Manifest

This file records binary/source artifacts stored inside this ZIP project archive.


## v2.0.23

- Folder: `releases/v2.0.23/`
- JAR: `CT-BN-Compat-1.21.1-v2.0.23.jar`
- JAR SHA-256: `1fcff03c89b9c6dc54b812b0869f2521daf5f8e6c90edd35337f0eee80e94c5a`
- Source ZIP: `CT-BN-Compat-1.21.1-v2.0.23-source.zip`
- Source SHA-256: `96a7dbc1b90408cabfcd394fdc4445add46bf37118dcd6069156464806704bab`

## v2.0.24

- JAR: `releases/v2.0.24/CT-BN-Compat-1.21.1-v2.0.24.jar`
- Source ZIP: `releases/v2.0.24/CT-BN-Compat-1.21.1-v2.0.24-source.zip`
- JAR SHA-256: `35380b5bababf83cebd15b620d6962104f16be83ada72b946024b098fce12638`
- Source ZIP SHA-256: `dc9643aec30ee679b4bbafb1c0d1e45ab81f92f99475a4dfbc23e82e25b4b69f`
- Status: diagnostic-only; annotation metadata correction.

## v2.1.0

- JAR: `releases/v2.1.0/CT-BN-Compat-1.21.1-v2.1.0.jar`
- Source snapshot: `releases/v2.1.0/CT-BN-Compat-1.21.1-v2.1.0-source.zip`
- JAR SHA-256: `27e6c3b4cbcea8c7c40fee154d2dab3da99a3647525e3c9eb6b85ba3956f477d`
- Source ZIP SHA-256: `e83003b27fa171d4fe82a230df92b2c600ee05eb55a7c09d9291b351b3f8328c`
- Type: diagnostic-only senior audit/cleanup baseline
