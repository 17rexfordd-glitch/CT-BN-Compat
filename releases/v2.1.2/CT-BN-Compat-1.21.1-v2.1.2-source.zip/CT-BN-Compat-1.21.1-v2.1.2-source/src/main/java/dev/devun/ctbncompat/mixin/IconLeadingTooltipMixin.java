package dev.devun.ctbncompat.mixin;

import dev.devun.ctbncompat.DiagnosticLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.pixeldreamstudios.iconleadingtooltip.neoforge.client.IconLeadingTooltipNeoForgeClient", remap = false)
public abstract class IconLeadingTooltipMixin {
    @Inject(
            method = "onItemTooltip(Lnet/neoforged/neoforge/event/entity/player/ItemTooltipEvent;)V",
            at = @At("HEAD"),
            require = 1,
            remap = false
    )
    private static void ctbn$iconTooltip(CallbackInfo ci) {
        DiagnosticLog.hookExecuted("ICON_LEADING_TOOLTIP", "IconLeadingTooltipNeoForgeClient.onItemTooltip");
        DiagnosticLog.owner("ICON_LEADING_TOOLTIP");
    }
}
