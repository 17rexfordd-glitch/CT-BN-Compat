package dev.devun.ctbncompat;

import dev.devun.ctbncompat.DiagnosticMixinPlugin.ResourceCheck;
import dev.devun.ctbncompat.DiagnosticMixinPlugin.ResourceStatus;
import dev.devun.ctbncompat.bridge.AbstractContainerScreenBridge;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.DefaultedRegistry;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;
import net.neoforged.neoforgespi.language.IModInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DiagnosticLog {
    private static final Logger LOGGER = LoggerFactory.getLogger("CT-BN-DIAG");
    private static final AtomicLong SEQ = new AtomicLong();
    private static final Set<String> ONCE = ConcurrentHashMap.newKeySet();

    private static volatile long frame;
    private static volatile long drawSeq;
    private static volatile ItemStack hoveredStack;
    private static volatile int lastStackIdentity;
    private static volatile int lastComponentHash = Integer.MIN_VALUE;
    private static volatile int lastTooltipHash = Integer.MIN_VALUE;
    private static volatile int lastTooltipCount = -1;
    private static volatile String lastItemId = "";
    private static volatile String colorTooltipsState = "state-not-yet-captured";
    private static volatile long lastRepeatNs;

    private static volatile String lastJeiHoverState = "";
    private static volatile String lastJeiPathState = "";
    private static volatile String lastJeiFollowupState = "";
    private static volatile long lastJeiHoverNs;
    private static volatile long lastJeiPathNs;
    private static volatile long lastJeiFollowupNs;
    private static volatile String lastJeiItemId = "none";
    private static volatile ItemStack lastJeiStack;
    private static final long JEI_RATE_LIMIT_NS = 500_000_000L;
    private static final long OWNER_RATE_LIMIT_NS = 500_000_000L;
    private static final Map<String, String> LAST_OWNER_STATE_BY_MOD = new ConcurrentHashMap<>();
    private static final Map<String, Long> LAST_OWNER_NS_BY_MOD = new ConcurrentHashMap<>();

    private static final Map<String, String> EXPECTED_OPTIONAL_VERSIONS = Map.of(
            "simplytooltips", "0.1.5",
            "jei", "19.44.0.403",
            "betteradvancedtooltips", "2101.1.0-build.5",
            "immersiveui", "0.3.3",
            "icon_leading_tooltip", "1.0.8"
    );

    private static volatile boolean runtimeVerificationComplete;
    private static int runtimeVerificationAttempts;
    private static final int MAX_RUNTIME_VERIFICATION_ATTEMPTS = 200;

    private DiagnosticLog() {}

    public static void log(String message) {
        LOGGER.info("[CT-BN-DIAG #" + SEQ.incrementAndGet() + "] " + message);
    }

    public static void applied(List<String> applied) {
        for (String entry : applied) {
            log("MIXIN-APPLIED-SNAPSHOT " + entry);
        }
    }

    public static void verifiedPrimaryHooks() {
        log("PRIMARY-HOOK-VERIFIED mod=SIMPLYTOOLTIPS target=net.sweenus.simplytooltips.client.render.TooltipRenderer method=render(GuiGraphics,Font,ItemStack,List,TooltipProvider,int,int,int,int) require=1");
        log("PRIMARY-HOOK-VERIFIED mod=SIMPLYTOOLTIPS target=net.sweenus.simplytooltips.client.render.TooltipRenderer method=render(GuiGraphics,Font,ItemStack,List,TooltipProvider,List,int,int,int,int) require=1");
        log("PRIMARY-HOOK-VERIFIED mod=JEI target=mezz.jei.gui.overlay.ingredients.IngredientGrid method=drawTooltips(Minecraft,GuiGraphics,int,int) require=1");
        log("PRIMARY-HOOK-VERIFIED mod=JEI target=mezz.jei.gui.overlay.ingredients.IngredientGrid method=drawTooltip(GuiGraphics,int,int,IElement) require=1");
        log("PRIMARY-HOOK-VERIFIED mod=JEI target=mezz.jei.common.gui.JeiTooltip method=prepareForIngredientTooltip(ITypedIngredient,IIngredientRenderer,IIngredientManager) require=1");
        log("PRIMARY-HOOK-VERIFIED mod=JEI target=mezz.jei.common.gui.JeiTooltip method=draw(GuiGraphics,int,int,ITypedIngredient,IIngredientRenderer,IIngredientManager) require=1");
        log("PRIMARY-HOOK-VERIFIED mod=JEI target=mezz.jei.neoforge.platform.RenderHelper method=renderTooltip(GuiGraphics,List,int,int,Font,ItemStack) require=1");
        log("PRIMARY-HOOK-VERIFIED mod=BETTER_ADVANCED_TOOLTIPS target=dev.latvian.mods.betteradvancedtooltips.BATClientEventHandler method=onItemTooltip(ItemTooltipEvent) require=1 static=true");
        log("PRIMARY-HOOK-VERIFIED mod=IMMERSIVEUI target=it.hurts.octostudios.immersiveui.util.CommonCode method=renderFloating(...) require=1 static=true");
        log("PRIMARY-HOOK-VERIFIED mod=ICON_LEADING_TOOLTIP target=net.pixeldreamstudios.iconleadingtooltip.neoforge.client.IconLeadingTooltipNeoForgeClient method=onItemTooltip(ItemTooltipEvent) require=1 static=true");
    }

    public static void hookExecuted(String mod, String hook) {
        once("hook-executed:" + mod + ":" + hook, "PRIMARY-HOOK-EXECUTED mod=" + mod + " hook=" + hook);
    }

    public static void once(String key, String message) {
        if (ONCE.add(key)) {
            log(message);
        }
    }

    public static void beginFrame(Object screen, int mouseX, int mouseY) {
        frame++;
        once("screen", "SCREEN-RENDER hook ACTIVE");
        if (frame <= 3) {
            log("FRAME " + frame + " screen=" + className(screen) + " mouse=" + mouseX + "," + mouseY);
        }
    }

    public static void screenHoveredProbe(Object screen, int mouseX, int mouseY) {
        if (!(screen instanceof AbstractContainerScreen<?> container)
                || !(container instanceof AbstractContainerScreenBridge bridge)) {
            return;
        }
        logSlot("HOVERED-SLOT source=TYPED-ACCESSOR", screen, bridge.ctbn$getHoveredSlot(), mouseX, mouseY, false);
    }

    public static void liveContainerFrame(Object screen, Slot hoveredSlot, int mouseX, int mouseY) {
        once("live-screen-frame-first", "LIVE-SCREEN-FRAME FIRST target=AbstractContainerScreen.render@RETURN");
        logSlot("LIVE-HOVER", screen, hoveredSlot, mouseX, mouseY, true);
    }

    public static void liveTooltipCall(String phase, Object screen, Slot hoveredSlot, int mouseX, int mouseY) {
        once("live-tooltip-call-" + phase, "LIVE-TOOLTIP-CALL " + phase + " FIRST target=AbstractContainerScreen.renderTooltip");
        ItemStack stack = stack(hoveredSlot);
        if (stack != null) {
            hoveredStack = stack;
        }
        String id = itemId(stack);
        log("LIVE-TOOLTIP-CALL " + phase
                + " frame=" + frame
                + " screen=" + className(screen)
                + " item=" + id + (isBetterNetherId(id) ? " BETTERNETHER-ITEM" : "")
                + " ITEM-IDENTITY=" + hex(stack == null ? 0 : System.identityHashCode(stack))
                + " componentHash=" + componentHash(stack)
                + " mouse=" + mouseX + "," + mouseY);
    }

    private static void logSlot(String prefix, Object screen, Slot slot, int mouseX, int mouseY, boolean live) {
        ItemStack stack = stack(slot);
        if (stack == null) {
            return;
        }
        hoveredStack = stack;
        String id = itemId(stack);
        int identity = System.identityHashCode(stack);
        int componentHash = componentHash(stack);
        boolean betterNether = isBetterNetherId(id);
        boolean changed = identity != lastStackIdentity || componentHash != lastComponentHash || !id.equals(lastItemId);

        if (changed || betterNether || frame <= 5) {
            String tag = "";
            if (betterNether) {
                tag = live ? " LIVE-HOVER BETTERNETHER ITEM" : " BETTERNETHER-ITEM";
            }
            log(prefix
                    + " frame=" + frame
                    + " screen=" + className(screen)
                    + " item=" + id + tag
                    + " ITEM-IDENTITY=" + hex(identity)
                    + " componentHash=" + componentHash
                    + " changed=" + changed
                    + " mouse=" + mouseX + "," + mouseY);
        }

        lastStackIdentity = identity;
        lastComponentHash = componentHash;
        lastItemId = id;
    }

    public static void reportTooltipMods() {
        ModList modList = ModList.get();
        if (modList == null) {
            log("OPTIONAL-RUNTIME-VERIFICATION INVALID reason=modlist-not-initialized runtimeVerification=false");
            return;
        }

        Map<String, IModInfo> runtimeMods = new HashMap<>();
        for (IModInfo info : modList.getMods()) {
            runtimeMods.put(info.getModId(), info);
        }

        Map<String, String> targets = DiagnosticMixinPlugin.optionalTargetsSnapshot();
        Map<String, String> owners = DiagnosticMixinPlugin.optionalOwnersSnapshot();
        Map<String, String> modIds = DiagnosticMixinPlugin.optionalModIdsSnapshot();

        for (String mixin : targets.keySet()) {
            String owner = owners.get(mixin);
            String modId = modIds.get(mixin);
            String target = targets.get(mixin);
            ResourceCheck bootstrap = DiagnosticMixinPlugin.bootstrapCheck(mixin);
            IModInfo info = runtimeMods.get(modId);
            boolean runtimePresent = info != null;
            String actualVersion = runtimePresent ? String.valueOf(info.getVersion()) : "<absent>";
            String expectedVersion = EXPECTED_OPTIONAL_VERSIONS.get(modId);

            if (bootstrap == null || bootstrap.status() == ResourceStatus.CHECK_FAILED) {
                log("OPTIONAL-RUNTIME-VERIFICATION owner=" + owner
                        + " modId=" + modId
                        + " runtimePresent=" + runtimePresent
                        + " actualVersion=" + actualVersion
                        + " bootstrapClass=CHECK_FAILED final=INVALID reason=bootstrap-class-check-failed");
                continue;
            }

            boolean bootstrapPresent = bootstrap.status() == ResourceStatus.PRESENT;
            String finalStatus;
            if (bootstrapPresent && runtimePresent) {
                finalStatus = "VERIFIED";
            } else if (!bootstrapPresent && !runtimePresent) {
                finalStatus = "CONSISTENT-ABSENT";
            } else {
                finalStatus = "INVALID";
            }

            String reason;
            if (bootstrapPresent && !runtimePresent) {
                reason = " reason=bootstrap-class-present-runtime-mod-absent";
            } else if (!bootstrapPresent && runtimePresent) {
                reason = " reason=runtime-mod-present-bootstrap-target-class-absent";
            } else {
                reason = "";
            }

            log("OPTIONAL-RUNTIME-VERIFICATION owner=" + owner
                    + " modId=" + modId
                    + " expectedVersion=" + expectedVersion
                    + " actualVersion=" + actualVersion
                    + " runtimePresent=" + runtimePresent
                    + " bootstrapClass=" + bootstrap.status()
                    + " target=" + target
                    + " final=" + finalStatus + reason);

            if (!reason.isEmpty()) {
                log("DIAGNOSTIC-INVARIANT-FAILED owner=" + owner
                        + " modId=" + modId + reason
                        + " target=" + target);
            }

            if (runtimePresent && expectedVersion != null && !expectedVersion.equals(actualVersion)) {
                log("DIAGNOSTIC-INVARIANT-FAILED owner=" + owner
                        + " modId=" + modId
                        + " reason=dependency-version-mismatch expected=" + expectedVersion
                        + " actual=" + actualVersion
                        + " diagnosticEvidence=INVALID");
            }
        }
    }

    public static void hoveredSlot(Object screen, int mouseX, int mouseY) {
        once("hover", "HOVERED-SLOT hook ACTIVE");
        if (screen instanceof AbstractContainerScreen<?> container
                && container instanceof AbstractContainerScreenBridge bridge) {
            logSlot("HOVERED-SLOT", screen, bridge.ctbn$getHoveredSlot(), mouseX, mouseY, false);
        }
    }

    public static void tooltipBegin(String path, ItemStack directStack, Object tooltip, int x, int y) {
        once("gui", "GUI-TOOLTIP hook ACTIVE");
        drawSeq++;

        ItemStack stack = directStack != null ? directStack : hoveredStack;
        String id = itemId(stack);
        boolean betterNether = isBetterNetherId(id);
        int identity = stack == null ? 0 : System.identityHashCode(stack);
        int componentHash = componentHash(stack);
        int tooltipCount = listSize(tooltip);
        int tooltipHash = tooltip == null ? 0 : tooltip.hashCode();

        boolean changed = identity != lastStackIdentity
                || componentHash != lastComponentHash
                || !id.equals(lastItemId)
                || tooltipHash != lastTooltipHash
                || tooltipCount != lastTooltipCount;

        long now = System.nanoTime();
        boolean repeatedVeryRecently = now - lastRepeatNs < 250_000_000L;

        if (changed || betterNether || drawSeq <= 12 || !repeatedVeryRecently) {
            log("TOOLTIP-BEGIN frame=" + frame
                    + " renderSeq=" + drawSeq
                    + " path=" + path
                    + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                    + " ITEM-IDENTITY=" + hex(identity)
                    + " componentHash=" + componentHash
                    + " tooltipCount=" + tooltipCount
                    + " tooltipHash=" + tooltipHash
                    + " x=" + x
                    + " y=" + y
                    + " changed=" + changed
                    + " callers=" + callerMods());
            lastRepeatNs = now;
        }

        logJeiFollowup("GUI-GRAPHICS", path, stack, x, y);

        lastStackIdentity = identity;
        lastComponentHash = componentHash;
        lastItemId = id;
        logJeiFollowup("GUI-GRAPHICS", "renderTooltipInternal", stack, x, y);

        lastTooltipHash = tooltipHash;
        lastTooltipCount = tooltipCount;
    }

    public static void tooltipInternal(Object tooltip, int x, int y, Object positioner) {
        drawSeq++;
        int tooltipCount = listSize(tooltip);
        int tooltipHash = tooltip == null ? 0 : tooltip.hashCode();
        ItemStack stack = hoveredStack;
        String id = itemId(stack);
        boolean betterNether = isBetterNetherId(id);
        boolean changed = tooltipHash != lastTooltipHash || tooltipCount != lastTooltipCount;

        if (changed || betterNether || drawSeq <= 12) {
            log("TOOLTIP-INTERNAL frame=" + frame
                    + " renderSeq=" + drawSeq
                    + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                    + " tooltipCount=" + tooltipCount
                    + " tooltipHash=" + tooltipHash
                    + " x=" + x
                    + " y=" + y
                    + " changed=" + changed
                    + " positioner=" + className(positioner)
                    + " callers=" + callerMods());
        }

        logJeiFollowup("GUI-GRAPHICS", "renderTooltipInternal", stack, x, y);

        lastTooltipHash = tooltipHash;
        lastTooltipCount = tooltipCount;
    }

    public static void ctObserved(String source, ItemStack stack) {
        String id = itemId(stack);
        log("COLORTOOLTIPS " + source
                + " frame=" + frame
                + " item=" + id + (isBetterNetherId(id) ? " BETTERNETHER-ITEM" : "")
                + " ITEM-IDENTITY=" + hex(stack == null ? 0 : System.identityHashCode(stack))
                + " componentHash=" + componentHash(stack));
        logJeiFollowup("COLORTOOLTIPS", source, stack, -1, -1);
    }

    public static void captureColorTooltipsState(
            ItemStack activeStack,
            boolean visibleRequested,
            boolean isTextOnlyMode,
            boolean needsAnimatorReset,
            long lostCandidateStartTimeMs,
            long switchFlashStartTimeMs,
            long fadeInStartTimeMs,
            Object lastState
    ) {
        colorTooltipsState = "activeStack@" + hex(activeStack == null ? 0 : System.identityHashCode(activeStack))
                + " visibleRequested=" + visibleRequested
                + " isTextOnlyMode=" + isTextOnlyMode
                + " needsAnimatorReset=" + needsAnimatorReset
                + " lostCandidateStartTimeMs=" + lostCandidateStartTimeMs
                + " switchFlashStartTimeMs=" + switchFlashStartTimeMs
                + " fadeInStartTimeMs=" + fadeInStartTimeMs
                + " lastState=" + String.valueOf(lastState);
    }

    public static void ctState(String action) {
        log("COLORTOOLTIPS " + action + " frame=" + frame + " " + colorTooltipsState);
    }

    public static void lifecycle(Object lifecycleType) {
        log("COLORTOOLTIPS LIFECYCLE=" + String.valueOf(lifecycleType) + " frame=" + frame);
    }

    public static void animator(String action) {
        log("COLORTOOLTIPS ANIMATOR=" + action + " frame=" + frame + " " + colorTooltipsState);
    }

    public static void jeiGridDrawTooltips(int mouseX, int mouseY, String runtimeMethod) {
        hookExecuted("JEI", runtimeMethod);
        once("jei-grid-tooltips-active", "JEI-TOOLTIP-PATH hook ACTIVE target=IngredientGrid.drawTooltips");
        logJeiPath("JEI-TOOLTIP-PATH phase=grid-drawTooltips"
                + " runtimeClass=mezz.jei.gui.overlay.ingredients.IngredientGrid"
                + " runtimeMethod=" + runtimeMethod
                + " mouse=" + mouseX + "," + mouseY
                + " currentJeiItem=" + lastJeiItemId
                + " colorTooltipsState=" + colorTooltipsState
                + " callers=" + callerMods(), "grid|" + mouseX + "|" + mouseY, false);
    }

    public static void jeiIngredientHover(
            Object element,
            Object typedIngredient,
            Object ingredient,
            Object ingredientType,
            ItemStack stack,
            int mouseX,
            int mouseY,
            String runtimeMethod
    ) {
        hookExecuted("JEI", runtimeMethod);
        once("jei-ingredient-hover-active", "JEI-INGREDIENT-HOVER hook ACTIVE target=IngredientGrid.drawTooltip typedExtraction=true reflection=false");

        rememberJeiStack(stack);
        String id = itemId(stack);
        boolean betterNether = isBetterNetherId(id);
        int identity = stack == null ? 0 : System.identityHashCode(stack);
        int componentHash = componentHash(stack);
        int count = stack == null ? 0 : stack.getCount();
        String state = runtimeMethod + "|" + mouseX + "|" + mouseY + "|" + id + "|" + identity + "|" + componentHash + "|" + count + "|" + className(element);
        long now = System.nanoTime();
        if (!state.equals(lastJeiHoverState) || betterNether || now - lastJeiHoverNs >= JEI_RATE_LIMIT_NS) {
            log("JEI-INGREDIENT-HOVER detected=true"
                    + " frame=" + frame
                    + " runtimeClass=" + className(element)
                    + " runtimeMethod=" + runtimeMethod
                    + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                    + " count=" + count
                    + " ITEM-IDENTITY=" + hex(identity)
                    + " componentHash=" + componentHash
                    + " typedIngredientClass=" + className(typedIngredient)
                    + " ingredientClass=" + className(ingredient)
                    + " ingredientTypeClass=" + className(ingredientType)
                    + " mouse=" + mouseX + "," + mouseY
                    + " vanillaHoveredSlotExpectedNull=true"
                    + " tooltipCreationPath=IngredientGrid.drawTooltip->IElement.getTooltip->JeiTooltip"
                    + " extraction=typed-jei-api reflection=false"
                    + " callers=" + callerMods());
            lastJeiHoverState = state;
            lastJeiHoverNs = now;
        }
    }

    public static void jeiTooltipPrepare(
            ItemStack stack,
            Object typedIngredient,
            Object ingredient,
            Object ingredientType,
            Object renderer,
            Object ingredientManager,
            String runtimeMethod
    ) {
        hookExecuted("JEI", runtimeMethod);
        rememberJeiStack(stack);
        String id = itemId(stack);
        boolean betterNether = isBetterNetherId(id);
        logJeiPath("JEI-TOOLTIP-CREATE phase=prepareForIngredientTooltip"
                + " frame=" + frame
                + " runtimeClass=mezz.jei.common.gui.JeiTooltip"
                + " runtimeMethod=" + runtimeMethod
                + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                + " count=" + (stack == null ? 0 : stack.getCount())
                + " ITEM-IDENTITY=" + hex(stack == null ? 0 : System.identityHashCode(stack))
                + " componentHash=" + componentHash(stack)
                + " typedIngredientClass=" + className(typedIngredient)
                + " ingredientClass=" + className(ingredient)
                + " ingredientTypeClass=" + className(ingredientType)
                + " rendererClass=" + className(renderer)
                + " ingredientManagerClass=" + className(ingredientManager)
                + " extraction=typed-jei-api reflection=false"
                + " callers=" + callerMods(), "prepare|" + id + "|" + className(renderer), betterNether);
    }

    public static void jeiTooltipDraw(
            Object tooltip,
            List<?> lines,
            ItemStack stack,
            int mouseX,
            int mouseY,
            Object typedIngredient,
            Object ingredient,
            Object ingredientType,
            Object renderer,
            Object ingredientManager,
            String runtimeMethod
    ) {
        hookExecuted("JEI", runtimeMethod);
        rememberJeiStack(stack);
        String id = itemId(stack);
        boolean betterNether = isBetterNetherId(id);
        int tooltipHash = lines == null ? 0 : lines.hashCode();
        logJeiPath("JEI-TOOLTIP-DRAW phase=JeiTooltip.draw"
                + " frame=" + frame
                + " runtimeClass=" + className(tooltip)
                + " runtimeMethod=" + runtimeMethod
                + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                + " count=" + (stack == null ? 0 : stack.getCount())
                + " ITEM-IDENTITY=" + hex(stack == null ? 0 : System.identityHashCode(stack))
                + " componentHash=" + componentHash(stack)
                + " tooltipCount=" + listSize(lines)
                + " tooltipHash=" + tooltipHash
                + " mouse=" + mouseX + "," + mouseY
                + " typedIngredientClass=" + className(typedIngredient)
                + " ingredientClass=" + className(ingredient)
                + " ingredientTypeClass=" + className(ingredientType)
                + " rendererClass=" + className(renderer)
                + " ingredientManagerClass=" + className(ingredientManager)
                + " colorTooltipsState=" + colorTooltipsState
                + " extraction=typed-jei-api getLines=typed reflection=false"
                + " callers=" + callerMods(), "draw|" + mouseX + "|" + mouseY + "|" + id + "|" + tooltipHash, betterNether);
    }

    public static void jeiRenderHandoff(ItemStack stack, List<?> tooltipElements, int mouseX, int mouseY, String runtimeMethod) {
        hookExecuted("JEI", runtimeMethod);
        rememberJeiStack(stack);
        String id = itemId(stack);
        boolean betterNether = isBetterNetherId(id);
        int tooltipHash = tooltipElements == null ? 0 : tooltipElements.hashCode();
        logJeiPath("JEI-RENDER-HANDOFF phase=RenderHelper.renderTooltip"
                + " frame=" + frame
                + " runtimeClass=mezz.jei.neoforge.platform.RenderHelper"
                + " runtimeMethod=" + runtimeMethod
                + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                + " count=" + (stack == null ? 0 : stack.getCount())
                + " ITEM-IDENTITY=" + hex(stack == null ? 0 : System.identityHashCode(stack))
                + " componentHash=" + componentHash(stack)
                + " tooltipCount=" + listSize(tooltipElements)
                + " tooltipHash=" + tooltipHash
                + " mouse=" + mouseX + "," + mouseY
                + " source=RenderHelper.renderTooltip->GuiGraphics.renderComponentTooltipFromElements"
                + " callers=" + callerMods(), "renderhelper|" + mouseX + "|" + mouseY + "|" + id + "|" + tooltipHash, true);
        logJeiFollowup("JEI", runtimeMethod, stack, mouseX, mouseY);
    }

    public static void owner(String mod) {
        ItemStack stack = hoveredStack != null ? hoveredStack : lastJeiStack;
        String id = itemId(stack);
        boolean betterNether = isBetterNetherId(id);
        boolean recent = recentJeiHover();
        int identity = stack == null ? 0 : System.identityHashCode(stack);
        int componentHash = componentHash(stack);
        String state = frame + "|" + id + "|" + identity + "|" + componentHash + "|" + recent;
        long now = System.nanoTime();
        String previous = LAST_OWNER_STATE_BY_MOD.get(mod);
        Long previousNs = LAST_OWNER_NS_BY_MOD.get(mod);
        boolean meaningful = betterNether || recent || !"none".equals(id);
        boolean repeatedState = state.equals(previous);
        boolean recentlyLogged = previousNs != null && now - previousNs < OWNER_RATE_LIMIT_NS;

        if (!repeatedState && (meaningful || !recentlyLogged)) {
            log("TOOLTIP-OWNER mod=" + mod
                    + " frame=" + frame
                    + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                    + " ITEM-IDENTITY=" + hex(identity)
                    + " componentHash=" + componentHash
                    + " recentJeiHover=" + recent
                    + " dedupe=state-change"
                    + " callers=" + callerMods());
            LAST_OWNER_STATE_BY_MOD.put(mod, state);
            LAST_OWNER_NS_BY_MOD.put(mod, now);
        }
        logJeiFollowup(mod, "TOOLTIP-OWNER", stack, -1, -1);
    }

    private static void logJeiPath(String message, String state, boolean force) {
        long now = System.nanoTime();
        if (force || !state.equals(lastJeiPathState) || now - lastJeiPathNs >= JEI_RATE_LIMIT_NS) {
            log(message);
            lastJeiPathState = state;
            lastJeiPathNs = now;
        }
    }

    private static void logJeiFollowup(String owner, String path, ItemStack stack, int mouseX, int mouseY) {
        if (!recentJeiHover()) {
            return;
        }
        ItemStack effectiveStack = stack != null ? stack : lastJeiStack;
        String id = itemId(effectiveStack);
        boolean betterNether = isBetterNetherId(id);
        String state = owner + "|" + path + "|" + id + "|" + mouseX + "|" + mouseY;
        long now = System.nanoTime();
        if (betterNether || !state.equals(lastJeiFollowupState) || now - lastJeiFollowupNs >= JEI_RATE_LIMIT_NS) {
            log("JEI-SUBSEQUENT-INVOKE owner=" + owner
                    + " path=" + path
                    + " frame=" + frame
                    + " item=" + id + (betterNether ? " BETTERNETHER-ITEM" : "")
                    + " ITEM-IDENTITY=" + hex(effectiveStack == null ? 0 : System.identityHashCode(effectiveStack))
                    + " componentHash=" + componentHash(effectiveStack)
                    + " mouse=" + mouseX + "," + mouseY
                    + " recentJeiHover=true"
                    + " lastJeiItem=" + lastJeiItemId
                    + " callers=" + callerMods());
            lastJeiFollowupState = state;
            lastJeiFollowupNs = now;
        }
    }

    private static boolean recentJeiHover() {
        return lastJeiHoverNs != 0L && System.nanoTime() - lastJeiHoverNs <= 2_000_000_000L;
    }

    private static void rememberJeiStack(ItemStack stack) {
        if (stack == null) {
            return;
        }
        hoveredStack = stack;
        lastJeiStack = stack;
        lastJeiItemId = itemId(stack);
    }

    private static String callerMods() {
        StackTraceElement[] trace = Thread.currentThread().getStackTrace();
        LinkedHashSet<String> mods = new LinkedHashSet<>();
        for (StackTraceElement element : trace) {
            String name = element.getClassName().toLowerCase(Locale.ROOT);
            if (name.contains("jei")) mods.add("JEI");
            if (name.contains("quark")) mods.add("QUARK");
            if (name.contains("simplytooltip")) mods.add("SIMPLYTOOLTIPS");
            if (name.contains("betteradvanced") || name.contains("advancedtooltip")) mods.add("BETTER-ADVANCED-TOOLTIPS");
            if (name.contains("icon") && name.contains("tooltip")) mods.add("ICON-LEADING-TOOLTIP");
            if (name.contains("rarity")) mods.add("RARITYCORE/INTEGRATION");
            if (name.contains("immersiveui")) mods.add("IMMERSIVEUI");
            if (name.contains("colortooltips")) mods.add("COLORTOOLTIPS");
            if (name.contains("betternether")) mods.add("BETTERNETHER");
        }
        return mods.isEmpty() ? "none" : String.join(",", mods);
    }

    private static ItemStack stack(Slot slot) {
        if (slot == null) {
            return null;
        }
        ItemStack stack = slot.getItem();
        return stack == null || stack.isEmpty() ? null : stack;
    }

    private static boolean isBetterNetherId(String id) {
        String lower = id.toLowerCase(Locale.ROOT);
        return lower.contains("betternether") || lower.contains("better_nether");
    }

    public static String itemId(ItemStack stack) {
        if (stack == null) {
            return "none";
        }
        DefaultedRegistry<Item> itemRegistry = BuiltInRegistries.ITEM;
        return String.valueOf(itemRegistry.getKey(stack.getItem()));
    }

    public static int componentHash(ItemStack stack) {
        if (stack == null) {
            return 0;
        }
        DataComponentMap components = stack.getComponents();
        return components == null ? 0 : components.hashCode();
    }

    private static int listSize(Object value) {
        return value instanceof List<?> list ? list.size() : -1;
    }

    private static String className(Object value) {
        return value == null ? "null" : value.getClass().getName();
    }

    private static String hex(int value) {
        return Integer.toHexString(value);
    }

    public static synchronized void reportTooltipModsDeferred() {
        if (runtimeVerificationComplete) {
            return;
        }
        if (runtimeVerificationAttempts >= MAX_RUNTIME_VERIFICATION_ATTEMPTS) {
            return;
        }

        runtimeVerificationAttempts++;
        ModList modList = ModList.get();
        if (modList == null) {
            if (runtimeVerificationAttempts == 1) {
                log("OPTIONAL-RUNTIME-VERIFICATION DEFERRED reason=modlist-not-initialized retry=true");
            }
            if (runtimeVerificationAttempts >= MAX_RUNTIME_VERIFICATION_ATTEMPTS) {
                log("OPTIONAL-RUNTIME-VERIFICATION ABANDONED reason=modlist-not-initialized retry-cap=200 startup-failure=false");
            }
            return;
        }

        reportTooltipMods();
        runtimeVerificationComplete = true;
        log("OPTIONAL-RUNTIME-VERIFICATION COMPLETE lifecycle=ClientTickEvent.Post retry=false");
    }
}
