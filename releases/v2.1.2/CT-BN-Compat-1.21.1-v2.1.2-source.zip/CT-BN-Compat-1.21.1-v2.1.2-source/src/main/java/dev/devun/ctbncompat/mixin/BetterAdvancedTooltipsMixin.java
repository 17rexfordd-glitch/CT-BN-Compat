package dev.devun.ctbncompat.mixin;

import dev.devun.ctbncompat.DiagnosticLog;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "dev.latvian.mods.betteradvancedtooltips.BATClientEventHandler", remap = false)
public abstract class BetterAdvancedTooltipsMixin {
    @Inject(
            method = "onItemTooltip(Lnet/neoforged/neoforge/event/entity/player/ItemTooltipEvent;)V",
            at = @At("HEAD"),
            require = 1,
            remap = false
    )
    private static void ctbn$bat(CallbackInfo ci) {
        DiagnosticLog.hookExecuted("BETTER_ADVANCED_TOOLTIPS", "BATClientEventHandler.onItemTooltip");
        DiagnosticLog.owner("BETTER_ADVANCED_TOOLTIPS");
    }
}
