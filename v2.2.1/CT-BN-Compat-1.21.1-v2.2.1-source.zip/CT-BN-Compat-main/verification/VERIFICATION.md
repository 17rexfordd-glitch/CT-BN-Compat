# CT-BN-Compat v2.2.1 verification

Final JAR SHA-256: `84f6203b2108fd227872f33173819a4f848eca8a2ea8cd47596336a4d56ebaee`
v2.2.0 baseline SHA-256: `b0451eb08ee9e8182ff4239153caf999e723fe9838db88ecbe0e1aadc1f25a5c`

## Build

Used Java 21, Gradle wrapper 8.14.3, Minecraft 1.21.1, NeoForge 21.1.248,
and the exact archived real JEI/ColorTooltips dependencies. Ran wrapper --stop,
deleted the verified new checkout's build directory, then clean and
build --no-build-cache --rerun-tasks. Final result: BUILD SUCCESSFUL; all seven
Gradle tasks executed. Cached external Minecraft/NeoForge preparation artifacts
were reused by NeoForm; project classes and tests were recompiled from source.
No manual classfile patching, stubs, or gameplay modifications.

## Headless tests

All 20 diagnostic tests passed as part of the final build. They cover ordered SHA-256
and Java hash collisions, immutable before snapshots, insertion/removal/modification
indexes, 1,000 stable frames with no more than 24 emitted records, ordinary repeated
handler additions, mutation attribution, changed handler input, one first-observed
point per frame, hover reentry, logical session changes, repeated stage occurrences,
new equal text objects, style changes, JEI Either unwrapping, rendered text extraction,
and explicit partial coverage for opaque elements. Tests use real text APIs; no test
classes are bundled in the release JAR. These are headless diagnostics tests, not a
Minecraft or Mixin-application gameplay test.

## Exact final packaged bytecode

- 30 Java 21 project classes; no duplicate entries or bundled dependency/stub/test classes.
- All 13 prior Mixin targets and injection selectors retained. Added only the read-only
  ClientTextTooltip bridge Mixin, for a total of 14. All @Mixin annotations retain CLASS
  retention in RuntimeInvisibleAnnotations. Inject.at uses the correct annotation array.
- All 35 exact injection targets and shadow fields exist in the real dependencies.
  All 72 Minecraft/NeoForge/JEI method instructions and eight field instructions resolve;
  interface invocation kinds were checked.
- Typed ItemTooltipEvent parameters appear in both HEAD and RETURN handlers for BAT and
  Icon Leading Tooltip. JEI prepare now has a return snapshot as well as its existing entry hook.
- EVENT_BUS:IEventBus, slots:NonNullList, and the previously corrected API descriptors remain.
  Main ACTIVE, bootstrap, and mod metadata all report 2.2.1; behavioral-fixes=false.
- No automatic EventBusSubscriber, reflection, normal runtime reference to the Mixin package,
  Redirect/Modify injection, callback cancellation, or return-value override. All inspected
  field writes target this mod's diagnostic classes. The new client text bridge only reads.
- Logical JEI comparison uses a baseline stack copy, count, and item/components equality.
  Object identity occurs only in diagnostic evidence and exact HEAD/RETURN event pairing,
  not in content hashes or logical hover keys. Startup events without a witnessed same-frame
  JEI hover are not attributed to JEI.

## Reading the next gameplay log

TOOLTIP-TRACE provides path, occurrence, frame/session/logical item, element count and
ordered SHA-256. TOOLTIP-MUTATION pairs a handler's actual before/after snapshots with
an event token and indexed deltas. TOOLTIP-FIRST-DIVERGENCE provides firstMutationOwner.
That field identifies the first observed changed stage compared with the corresponding
stage occurrence in the previous frame. Changed BEFORE input is labelled upstream-of
the handler, rather than blamed on the handler. Paired changes identify what the handler
itself changed. Normal identical before/after additions are deduped across frames.

Grid and ColorTooltips do not expose tooltip lists at these hooks. They say so; ColorTooltips
records an explicitly inherited last-sampled fingerprint and captured activeStack state.
That evidence must not be interpreted as a fresh ColorTooltips content snapshot.

Styled text fingerprints include glyphs, color, bold/italic/underline/strikethrough/
obfuscation and font. Unknown visuals expose class/size or class only, explicitly labelled
coverage=opaque-*. They may change internally without changing that partial fingerprint.
Snapshot failures are marked partial. Output previews and delta lists are bounded (eight
entries per category); hashes include complete sampled content. Very large lists use an
explicit positional alignment fallback. No claim of complete observation of uninstrumented
handlers or opaque custom visuals is made.

The live instance was not modified or launched. The next gameplay test must still determine
which actual element and owner/path causes the observed flicker. No final behavior fix is included.

## Included evidence

Final stop/clean/build logs, bytecode regression and target-verification logs, instruction
references, source diff, test source, and ASM verifier source are included. The verifiers
use ASM 9.7.1 and asm-tree from the Gradle distribution. Compile VerifyJar, Verify221 and
VerifyTargets together. Verify221 takes baseline JAR, release JAR, and references output
path. VerifyTargets takes release JAR and a newline-separated list of absolute dependency
JAR paths (NeoForge merged/compiled artifacts first, reference-dependencies next, remaining
Gradle dependencies last). No Minecraft classes are loaded by these static verifiers.
