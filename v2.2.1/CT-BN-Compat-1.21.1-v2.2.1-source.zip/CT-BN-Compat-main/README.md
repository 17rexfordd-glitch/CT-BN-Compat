# CT-BN-Compat v2.2.1

Diagnostic-only tracing to identify the first tooltip element that changes during a logically
stable JEI hover. This release does not implement a flicker or animation behavior fix.

## What changed

BAT and Icon Leading Tooltip have paired entry/return snapshots for the same tooltip event.
The log contains ordered SHA-256 content fingerprints, per-element types/text/style hashes,
and added/removed/modified indexes. JEI preparation, render handoff, and rendered client text
are correlated by frame, hover session, logical item, and stage occurrence. The original 13
Mixins remain; one read-only client-text bridge Mixin is added.

Repeated stable ownership, JEI path, followup, and ColorTooltips observations are deduped by
logical state. Java object identity is logged only as supporting evidence. Normal unchanged
records have a heartbeat no faster than five seconds. Content changes emit immediately.

`firstMutationOwner=<path>` means first observed divergence between consecutive frames.
A changed handler input is labelled `upstream-of-...`; it does not prove that handler caused it.
The paired `TOOLTIP-MUTATION` record shows exactly what a handler changed during that call.

## Build and checks

Java 21 and the included Gradle 8.14.3 wrapper are required. Keep reference-dependencies/.
Run `gradlew.bat --stop`, remove this checkout's build directory, then `gradlew.bat clean`
and `gradlew.bat build --no-build-cache --rerun-tasks`. On Unix use `./gradlew` instead.
First build needs network access for real Minecraft/NeoForge dependencies. The build's
`diagnosticTest` task runs headless snapshot, diff, attribution, style, and 1,000-frame dedupe tests.
No test doubles or reference mod classes are bundled in the release JAR.

Output: build/libs/CT-BN-Compat-1.21.1-v2.2.1.jar. See verification/ for final JAR checks.
If Java's local socket creation fails in a Windows app environment, set JVM property
`jdk.net.unixdomain.tmpdir` to an existing writable directory before invoking Gradle.

## Next gameplay test

Close Minecraft and replace the existing CT-BN JAR with v2.2.1 (only one CT-BN version loaded).
Open a world and inventory. Hover the JEI ingredient image for
`betternether:flaming_ruby_pickaxe` without moving the mouse, then move off and back once.
Retain that launch's debug.log and any crash report.

Search for `TOOLTIP-FIRST-DIVERGENCE`, `firstMutationOwner=`, and `TOOLTIP-MUTATION`.
The delta includes exact element indexes, type, bounded text preview, and full SHA-256.
Follow the same session/frame/logicalItem through BEFORE and AFTER and the later JEI stages.
Grid/ColorTooltips records explicitly say when content was not directly exposed; inherited
fingerprints are correlation evidence only.

Unknown visuals have explicit `coverage=opaque-*` labels. Their internal content may change
without a changed type/size fingerprint. The first observed point is not proof about an
unobserved third-party handler. Do not implement a behavior fix until the gameplay evidence
identifies the changing component and owner.

The live mods folder is not modified by this build. Headless and static checks do not replace
an in-game test of v2.2.1. Historical releases/references are preserved in the rolling archive;
the source ZIP excludes release history to avoid recursive archive growth.
