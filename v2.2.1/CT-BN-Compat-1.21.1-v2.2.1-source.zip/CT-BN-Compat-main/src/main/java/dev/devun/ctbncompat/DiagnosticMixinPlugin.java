package dev.devun.ctbncompat;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public final class DiagnosticMixinPlugin implements IMixinConfigPlugin {
    private static final ConcurrentLinkedQueue<String> APPLIED = new ConcurrentLinkedQueue<>();

    private static final Map<String, String> OPTIONAL_TARGETS = Map.of(
            "SimplyTooltipsRendererMixin", "net.sweenus.simplytooltips.client.render.TooltipRenderer",
            "JeiTooltipMixin", "mezz.jei.common.gui.JeiTooltip",
            "JeiIngredientGridMixin", "mezz.jei.gui.overlay.ingredients.IngredientGrid",
            "JeiRenderHelperMixin", "mezz.jei.neoforge.platform.RenderHelper",
            "BetterAdvancedTooltipsMixin", "dev.latvian.mods.betteradvancedtooltips.BATClientEventHandler",
            "ImmersiveUiRenderMixin", "it.hurts.octostudios.immersiveui.util.CommonCode",
            "IconLeadingTooltipMixin", "net.pixeldreamstudios.iconleadingtooltip.neoforge.client.IconLeadingTooltipNeoForgeClient"
    );

    private static final Map<String, String> OPTIONAL_OWNERS = Map.of(
            "SimplyTooltipsRendererMixin", "SIMPLYTOOLTIPS",
            "JeiTooltipMixin", "JEI",
            "JeiIngredientGridMixin", "JEI",
            "JeiRenderHelperMixin", "JEI",
            "BetterAdvancedTooltipsMixin", "BETTER_ADVANCED_TOOLTIPS",
            "ImmersiveUiRenderMixin", "IMMERSIVEUI",
            "IconLeadingTooltipMixin", "ICON_LEADING_TOOLTIP"
    );

    private static final Map<String, String> OPTIONAL_MOD_IDS = Map.of(
            "SimplyTooltipsRendererMixin", "simplytooltips",
            "JeiTooltipMixin", "jei",
            "JeiIngredientGridMixin", "jei",
            "JeiRenderHelperMixin", "jei",
            "BetterAdvancedTooltipsMixin", "betteradvancedtooltips",
            "ImmersiveUiRenderMixin", "immersiveui",
            "IconLeadingTooltipMixin", "icon_leading_tooltip"
    );

    private static final ConcurrentHashMap<String, ResourceCheck> BOOTSTRAP_CHECKS = new ConcurrentHashMap<>();

    public enum ResourceStatus {
        PRESENT,
        ABSENT,
        CHECK_FAILED
    }

    public record ResourceCheck(ResourceStatus status, String loader, Throwable error) {}

    public static List<String> appliedSnapshot() {
        return List.copyOf(APPLIED);
    }

    public static Map<String, String> optionalTargetsSnapshot() {
        return Map.copyOf(OPTIONAL_TARGETS);
    }

    public static Map<String, String> optionalOwnersSnapshot() {
        return Map.copyOf(OPTIONAL_OWNERS);
    }

    public static Map<String, String> optionalModIdsSnapshot() {
        return Map.copyOf(OPTIONAL_MOD_IDS);
    }

    public static ResourceCheck bootstrapCheck(String mixinSimpleName) {
        return BOOTSTRAP_CHECKS.get(mixinSimpleName);
    }

    @Override
    public void onLoad(String mixinPackage) {
        bootLog("MIXIN-PLUGIN-BOOTSTRAP-SAFE version=2.2.1 strategy=class-resource-only no-fml-runtime-state=true");
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        String simpleName = mixinClassName.substring(mixinClassName.lastIndexOf('.') + 1);
        String target = OPTIONAL_TARGETS.get(simpleName);
        if (target == null) {
            return true;
        }

        String owner = OPTIONAL_OWNERS.get(simpleName);
        String modId = OPTIONAL_MOD_IDS.get(simpleName);
        String resourceName = target.replace('.', '/') + ".class";
        ResourceCheck check = checkClassResource(resourceName);
        BOOTSTRAP_CHECKS.put(simpleName, check);

        if (check.status() == ResourceStatus.PRESENT) {
            bootLog("OPTIONAL-MIXIN ENABLED owner=" + owner
                    + " modId=" + modId
                    + " version=<deferred-bootstrap> modPresence=DEFERRED_BOOTSTRAP mixin=" + simpleName
                    + " target=" + target
                    + " detection=target-class-resource loader=" + check.loader()
                    + " reason=target-class-resource-present");
            return true;
        }

        if (check.status() == ResourceStatus.ABSENT) {
            bootLog("OPTIONAL-MIXIN SKIPPED owner=" + owner
                    + " modId=" + modId
                    + " version=<deferred-bootstrap> modPresence=DEFERRED_BOOTSTRAP mixin=" + simpleName
                    + " target=" + target
                    + " detection=target-class-resource reason=target-class-resource-absent-bootstrap");
            return false;
        }

        bootLog("OPTIONAL-DETECTION-DEFERRED owner=" + owner
                + " modId=" + modId
                + " version=<deferred-bootstrap> modPresence=UNKNOWN mixin=" + simpleName
                + " target=" + target
                + " detection=target-class-resource reason=resource-check-failed error=" + errorType(check.error())
                + " action=SAFE-SKIP");
        bootLog("OPTIONAL-MIXIN SKIPPED owner=" + owner
                + " modId=" + modId
                + " mixin=" + simpleName
                + " target=" + target
                + " reason=detection-unavailable-at-bootstrap action=SAFE-SKIP");
        return false;
    }

    private static ResourceCheck checkClassResource(String resourceName) {
        try {
            ClassLoader pluginLoader = DiagnosticMixinPlugin.class.getClassLoader();
            if (pluginLoader != null) {
                URL resource = pluginLoader.getResource(resourceName);
                if (resource != null) {
                    return new ResourceCheck(ResourceStatus.PRESENT, "plugin-classloader", null);
                }
            }

            ClassLoader contextLoader = Thread.currentThread().getContextClassLoader();
            if (contextLoader != null && contextLoader != pluginLoader) {
                URL resource = contextLoader.getResource(resourceName);
                if (resource != null) {
                    return new ResourceCheck(ResourceStatus.PRESENT, "context-classloader", null);
                }
            }

            return new ResourceCheck(ResourceStatus.ABSENT, "searched-plugin-and-context-classloaders", null);
        } catch (Throwable t) {
            return new ResourceCheck(ResourceStatus.CHECK_FAILED, "resource-lookup-failed", t);
        }
    }

    private static String errorType(Throwable t) {
        return t == null ? "<none>" : t.getClass().getName();
    }

    private static void bootLog(String message) {
        System.out.println("[CT-BN-DIAG] " + message);
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
        String entry = mixinClassName + " -> " + targetClassName;
        APPLIED.add(entry);
        bootLog("MIXIN-APPLIED " + entry);
    }
}
