package dev.devun.ctbncompat;

import dev.devun.ctbncompat.trace.TraceModel;
import dev.devun.ctbncompat.trace.TraceModel.*;
import dev.devun.ctbncompat.bridge.ClientTextTooltipBridge;
import com.mojang.datafixers.util.Either;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import java.util.*;

/** Headless diagnostic tests: no game launch, no tooltip mutation, no production stubs. */
public final class TraceTests {
    private static int checks;
    private static void check(boolean b,String message) { if(!b)throw new AssertionError(message);checks++; }
    private static Element line(String s) { return new Element("text",s,TraceModel.hash(s),"plain-text"); }
    private static Snapshot lines(String...s) { return Snapshot.of(Arrays.stream(s).map(TraceTests::line).toList()); }
    public static void main(String[] args) {
        check(!lines("FB").hash().equals(lines("Ea").hash()),"Java hash collision must not hide a text change");
        check(!lines("a","b").hash().equals(lines("b","a").hash()),"Ordered fingerprint");
        String added=TraceModel.diff(lines("a","c"),lines("a","b","c"));
        check(added.contains("added=[{index=1")&&added.contains("modified=[]"),"Insertion must not shift every line into modified");
        check(TraceModel.diff(lines("a","b","c"),lines("a","c")).contains("removed=[{index=1"),"Removal index");
        check(TraceModel.diff(lines("a","b"),lines("a","x")).contains("modified=[{index=1"),"Modification index");
        var mutable=new ArrayList<>(List.of(line("a")));var snap=Snapshot.of(mutable);mutable.clear();
        check(snap.elements().size()==1,"Before snapshot remains immutable");
        var log=new ArrayList<String>();var r=new Recorder(log::add);
        for(int frame=1;frame<=1000;frame++) {
            long now=frame*16_000_000L;r.begin(frame,"betternether:pickaxe/count=1/components=stable");
            r.emit("grid","logical",now,"grid identity="+frame);
            r.stage("BAT.BEFORE",lines("name"),now,"event="+frame);
            r.stage("BAT.AFTER",lines("name","durability"),now,"event="+frame);
            r.pair("BAT",frame,lines("name"),lines("name","durability"),now,"identity="+frame);
            r.stage("JeiTooltip.draw",lines("name","durability"),now,"");
            r.emit("ColorTooltips.update",r.inheritedFingerprint(),now,"update identity="+frame);
        }
        check(log.size()<=24,"1000 unchanged frames must be quiet, actual records="+log.size());
        check(log.stream().noneMatch(s->s.contains("FIRST-DIVERGENCE")),"Repeated normal handler additions are not consecutive-frame divergence");
        int before=log.size();r.begin(1001,"betternether:pickaxe/count=1/components=stable");
        r.stage("BAT.BEFORE",lines("name"),16_016_000_000L,"");
        r.stage("BAT.AFTER",lines("name","durability 99"),16_016_000_000L,"");
        check(log.subList(before,log.size()).stream().anyMatch(s->s.contains("firstMutationOwner=BAT.AFTER")&&s.contains("index=1")),"Unchanged input / changed output identifies BAT and exact line");
        log.clear();r=new Recorder(log::add);
        for(int frame=1;frame<=2;frame++) {
            r.begin(frame,"same-item");
            r.stage("BAT.BEFORE",lines(frame==1?"one":"two"),frame,"");
            r.stage("BAT.AFTER",lines(frame==1?"one":"two"),frame,"");
        }
        check(log.stream().anyMatch(s->s.contains("firstMutationOwner=upstream-of-BAT.BEFORE")),"Changed handler input must not blame BAT");
        check(log.stream().filter(s->s.contains("FIRST-DIVERGENCE")).count()==1,"One first observed mutation per frame");
        log.clear();r.begin(8,"same-item");r.stage("BAT.BEFORE",lines("two"),8,"");
        check(!log.isEmpty()&&log.stream().noneMatch(s->s.contains("FIRST-DIVERGENCE")),"Hover reentry emits fresh snapshot without stale comparison");
        log.clear();r.begin(9,"different-count-or-components");r.stage("BAT.BEFORE",lines("x"),9,"");
        check(log.stream().noneMatch(s->s.contains("FIRST-DIVERGENCE")),"Logical item change resets comparison");
        log.clear();r=new Recorder(log::add);
        for(int frame=1;frame<=100;frame++) {
            r.begin(frame,"same");
            r.stage("prepare",lines("a"),frame,"");r.stage("prepare",lines("b"),frame,"");
            r.pair("BAT",frame,lines("a"),lines("b"),frame,"");r.pair("BAT",frame,lines("b"),lines("c"),frame,"");
        }
        check(log.size()==4,"Repeated distinct occurrences must not alternate a single dedupe key");
        var plain=TooltipTrace.element(Component.literal("Pickaxe"));
        var copy=TooltipTrace.element(Component.literal("Pickaxe"));
        var styled=TooltipTrace.element(Component.literal("Pickaxe").withStyle(Style.EMPTY.withBold(true)));
        check(plain.hash().equals(copy.hash()),"New Component objects with equal visible content remain stable");
        check(!plain.hash().equals(styled.hash()),"Style-only mutation detected");
        check(TooltipTrace.element(Either.left(Component.literal("Pickaxe"))).hash().equals(plain.hash()),"JEI Either unwrapped");
        class ClientText implements ClientTextTooltipBridge { public FormattedCharSequence ctbn$getText(){return FormattedCharSequence.forward("Pickaxe",Style.EMPTY);} }
        check(TooltipTrace.element(new ClientText()).hash().equals(plain.hash()),"Rendered text uses readable styled contents");
        check(TooltipTrace.element(new Object()).coverage().equals("opaque-type-only"),"Unknown visual content is explicitly partial, never object identity");
        check(TooltipTrace.element(new Object()).hash().equals(TooltipTrace.element(new Object()).hash()),"Opaque object allocation cannot create false content changes");
        System.out.println("PASS "+checks+" diagnostic checks; 1000-frame stable-hover, mutation attribution, diff, logical sessions, occurrence, and real text adapter tests.");
    }
}
