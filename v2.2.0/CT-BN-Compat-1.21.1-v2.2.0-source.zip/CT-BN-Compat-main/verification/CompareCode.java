import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public class CompareCode {
    static Map<String,byte[]> methods(byte[] b) {
        ClassNode n=new ClassNode();new ClassReader(b).accept(n,ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
        var result=new TreeMap<String,byte[]>();
        for(var m:n.methods) {
            m.visibleAnnotations=null;m.invisibleAnnotations=null;
            var w=new ClassWriter(0);w.visit(65,1,"Comparison",null,"java/lang/Object",null);
            m.accept(w);w.visitEnd();result.put(m.name+m.desc,w.toByteArray());
        }
        return result;
    }
    public static void main(String[] args)throws Exception {
        var a=VerifyJar.entries(args[0]);var b=VerifyJar.entries(args[1]); int same=0, different=0;
        for(var e:b.entrySet()) if(e.getKey().endsWith(".class")) {
            var am=methods(a.get(e.getKey()));var bm=methods(e.getValue());
            for(var m:bm.entrySet()) {
                if(Arrays.equals(am.get(m.getKey()),m.getValue()))same++;
                else {different++;System.out.println("CHANGED "+e.getKey()+" "+m.getKey());}
            }
        }
        System.out.println("Identical methods (excluding debug, frames and annotations): "+same+"; changed: "+different);
    }
}
