# v2.2.0 packaged JAR verification

Baseline JAR SHA-256: 89fe544a3487b39963c40c79524d9cd8b2c3f0dd20455140b82e11c4570d9952
Release JAR SHA-256: b0451eb08ee9e8182ff4239153caf999e723fe9838db88ecbe0e1aadc1f25a5c

## Results

- Gradle 8.14.3 clean build succeeded with Java 21 against NeoForge 21.1.248 / Minecraft 1.21.1. No unit tests existed in the supplied project (test NO-SOURCE); this is not an in-game test.
- All 22 packaged classes are Java 21 major 65 and belong to dev/devun/ctbncompat. No duplicate ZIP entries or dependency/stub classes.
- All 13 configured Mixins have RuntimeInvisibleAnnotations @Mixin. All injection selectors, target classes, require settings, shadow metadata, and Mixin configuration match the baseline semantically.
- All 32 exact injection targets and shadow fields were found in the real dependency classfiles. All 45 Minecraft/NeoForge/JEI method instructions and 6 field instructions resolve. Interface invocation kinds were checked too.
- @Mod.dist is a one-element CLIENT enum array. No automatic EventBusSubscriber or java/lang/reflect references. No normal runtime class references the defined Mixin package.
- GETSTATIC NeoForge.EVENT_BUS:IEventBus and GETFIELD AbstractContainerMenu.slots:NonNullList verified. ArtifactVersion, DefaultedRegistry, and DataComponentMap descriptor fixes retained; known bad descriptors absent.
- Main ACTIVE, bootstrap, and metadata version markers are 2.2.0; behavioral-fixes=false and runtime anchor retained.
- Direct disassembly confirms System.nanoTime, elapsed-time comparison against 5,000,000,000 ns, early return for unchanged hover before the heartbeat, timestamp update only after logging, and screen identity reset.
- 128 of 134 methods have identical serialized bytecode after ignoring debug information, stack frames, and annotations. Every Mixin method body and existing ColorTooltips/tooltip-owner dedupe method is unchanged.

The six changed methods are the two runtime hover methods, main constructor and plugin onLoad version markers, plus DiagnosticLog.itemId and componentHash. The latter two are compiler corrections from the same source against real APIs: getKey uses INVOKEINTERFACE and ResourceLocation return, and DataComponentMap.hashCode uses its interface method. The historical JAR used a bad getKey(Object):Object invocation.

The historical Inject.at metadata used a scalar annotation. Real compilation emits the API's At[] array. The semantic comparison normalizes that historical scalar for comparison, and separately requires actual arrays in every final Inject annotation. No classfile patching was used for this release.

## Scope and limits

The build and all listed checks passed on the actual packaged release JAR. No Minecraft process was started and no live mods were changed. These static checks do not prove in-game Mixin application, inventory access, JEI hover, or a fix for tooltip flicker. Use the reproduction instructions in README.md and retain same-launch debug.log/crash artifacts.

## Evidence and rerunning

build-final.log, verification.log, target-verification.txt, bytecode-references.txt, code-comparison.txt, runtime-hover-bytecode.txt, and source-changes.patch are included.

VerifyJar.java, CompareCode.java, and VerifyTargets.java use ASM 9.7.1 and asm-tree 9.7.1 (available in Gradle 8.14.3/lib). Compile all three with javac using those two JARs on the classpath.

Run VerifyJar with baseline.jar, release.jar, and reference-output.txt arguments. Run CompareCode with baseline.jar and release.jar. Run VerifyTargets with release.jar and a text file containing one absolute dependency JAR path per line: NeoForge merged and NeoForge compiled artifacts from build/moddev/artifacts first, reference-dependencies/*.jar next, and the Gradle build dependency JARs last. It inspects classfiles without loading Minecraft or applying Mixins.