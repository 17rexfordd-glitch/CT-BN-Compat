# CT-BN-Compat v2.2.0

Diagnostic-only compatibility investigation for Minecraft 1.21.1, NeoForge 21.1.248, ColorTooltips 1211.3.4, and JEI 19.44.0.403. No tooltip or animation behavior fix is included.

## Changes from v2.1.3

- BetterNether RUNTIME-HOVER logs emit on changed state or a five-second heartbeat, instead of every client tick. Screen changes and leaving an occupied slot reset the diagnostic dedupe.
- Main, bootstrap, and mod metadata versions are synchronized to 2.2.0. The supplied source had a stale 2.1.0 bootstrap marker.
- The project now builds from source with Java 21 and the real NeoForge API. Archived ColorTooltips and JEI JARs supply the typed compile dependencies. No stubs or dependencies are packaged in the mod JAR.
- Real compilation corrects the historical DiagnosticLog.itemId invocation to INVOKEINTERFACE DefaultedRegistry.getKey(Object):ResourceLocation. It also emits the proper Inject.at annotation array. Injection targets and diagnostic intent are unchanged.

The previous IEventBus, NonNullList, ArtifactVersion, DefaultedRegistry, and DataComponentMap descriptor fixes are preserved, along with all 13 Mixins, all JEI hooks, the runtime anchor, ColorTooltips no-live-item dedupe, and tooltip-owner dedupe.

## Build

Install Java 21, then run `gradlew.bat clean build` on Windows or `./gradlew clean build` elsewhere. The wrapper uses Gradle 8.14.3. First build requires network access for Gradle, NeoForge, and Minecraft dependencies. Keep reference-dependencies beside build.gradle.

Output: `build/libs/CT-BN-Compat-1.21.1-v2.2.0.jar`.

If a Windows app environment fails with `Unable to establish loopback connection`, set the JVM property `jdk.net.unixdomain.tmpdir` to an existing writable directory before running Gradle. This is an environment workaround, not a mod setting.

## Installation and reproduction

Close Minecraft. Back up/remove the old CT-BN JAR from the instance's mods folder and place only v2.2.0 there; do not load both versions. The builder has not changed the live mods folder.

Open the world and InventoryScreen, then hover a real JEI ingredient image. Look for ACTIVE-CONTAINER, PRIMARY-HOOK-EXECUTED mod=JEI, and recentJeiHover=true. A null vanilla hoveredSlot during JEI hover is not itself a failure. Hover an unchanged BetterNether inventory stack to check the five-second RUNTIME-HOVER heartbeat; moving away/back or changing the stack should log immediately.

This release passed clean build and packaged-bytecode checks. It has not been launched in Minecraft; in-game Mixin application and tooltip reproduction remain untested.

## Archive contents

The source ZIP includes current source, build wrapper, reference dependencies, and verification tools/evidence. It excludes historical release ZIPs to avoid recursive archive growth. The rolling archive retains all supplied historical releases and reference dependencies, the original v2.1.3 source archive, and the new v2.2.0 JAR/source ZIP.

Historical source recovery provenance remains in RECOVERY-NOTES.md. See verification/VERIFICATION.md for the release audit.